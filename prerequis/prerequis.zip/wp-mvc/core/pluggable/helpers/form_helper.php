<?php

class FormHelper extends MvcFormHelper {

}

?>